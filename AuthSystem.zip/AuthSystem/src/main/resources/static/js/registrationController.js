var app=angular.module('angularApp',[])
                .directive('fallbackSrc', function () {
                    var fallbackSrc = {
                    link: function postLink(scope, iElement, iAttrs) {
                        iElement.bind('error', function() {
                        angular.element(this).attr("src", iAttrs.fallbackSrc);
                        });
                    }
                    }
                    return fallbackSrc;
                })
                .controller('registrationController',function($scope,$http){
                    $scope.imagepath="../resource/new_images/logo.jpeg";	
                    
                    
                    $scope.dataFilter="";
                    $scope.newData={serialNo:'0',name:'',quantity:'0',category:'',price:'0',size:'0',subTotal:'0'
                    ,grandTotal:'0',menuName:'',menuPrice:'0',imagePath:''};
                    var url="https://stackpoint.tech/"+"insertOrder.php";
                    $scope.cartData=[];
                    $scope.cartObj={serialNo:'0',quantity:'0',subTotal:'0',menuName:'',menuPrice:'0',imagePath:''};
                    $scope.addOrder=function(index)
                    {
                    console.log("Company Data Add 0");
                        var flag=0;
                            try
                            {
                                console.log("Company Data Add 1");

                                for(var i=0;i<$scope.cartData.length;i++)
                                {
                                    console.log("Company Data Add 2");

                                    if($scope.Menu1[index].tag==$scope.cartData[i].tag)
                                    {
                                        console.log("Company Data Add 3");

                                        if(parseInt($scope.cartData[i].quantity)>0)
                                            $scope.cartData[i].quantity=parseInt($scope.cartData[i].quantity)+1;
                                        else
                                            $scope.cartData[i].quantity='0';
                                        flag=1;    
                                    }    
                                }
                                console.log("Company Data Add 4");

                                if(flag==0)
                                {
                                    $scope.Menu1[index].quantity=1;
                                    $scope.cartData.push($scope.Menu1[index]);
                                }   
                                console.log("Company Data Add 5");

                            }catch(e)
                            {
                                console.log(e);
                            }

                        //$scope.Menu1[index].index=$scope.cartData.length+1;
                        //$scope.cartData.push($scope.Menu1[index]);
                        //$scope.cartObj={serialNo:'0',quantity:'0',subTotal:'0',menuName:'',menuPrice:'0',imagePath:''};
                        //window.alert("Company Data Added");
                                
                    }
                    $scope.changeMenu=function(menu)
                    {
                        if(menu=="Pizza")
                        {
                            $scope.Menu1=$scope.Pizza;
                        }
                        else if(menu=="Main Course")
                        {
                            $scope.Menu1=$scope.MainCourse;
                        }
                        else if(menu=="Drink")
                        {
                            $scope.Menu1=$scope.Drink;
                        }
                        //window.alert("Pizza Clicked");
                    }
                            
                    $scope.removeOrder=function(index)
                    {
                    
                        //console.log($scope.Data[index]);
                        $scope.cartData.splice(index, 1);
                        //this.data.remove=true;
                        //window.alert("order From List");
                    }
                    $scope.increaseQuantity=function(index)
                    {
                        try
                        {
                            if(parseInt($scope.cartData[index].quantity)>=0)
                                $scope.cartData[index].quantity=parseInt($scope.cartData[index].quantity)+1;
                            else
                                $scope.cartData[index].quantity='0';
                        }catch(e)
                        {
                            console.log(e);
                        }	
                    
                    }
                    $scope.reduceQuantity=function(index)
                    {
                        try
                        {
                            if(parseInt($scope.cartData[index].quantity)>0)
                                $scope.cartData[index].quantity=parseInt($scope.cartData[index].quantity)-1;
                            else
                                $scope.cartData[index].quantity='0';
                        }catch(e)
                        {
                            console.log(e);
                        }	
                    
                    }	
                    function reorder()
                    {
                        for(var i=0;i<$scope.Data.length;i++)
                        {
                            $scope.Data[i].serialNo=i+1;
                        }	
                    }			
                    $scope.placeOrder=function()
                    {
                        var request = $http({
                                    method: "post",
                                    url: url,
                                    data:$scope.Data,
                            headers: { 'Content-Type': 'x-www-form-urlencoded',
                            'Content-Type':'Access-Control-Allow-Headers'  }
                        });

                        /* Check whether the HTTP Request is successful or not. */
                        request.then(function (data) {
                            console.log(data);
                            alert("Data inserted successfull");
                        });	
                    }


                    url="http://stackpoint.tech/"+"fetchData.php";
                    console.log(url);	
                    $scope.productData=[];
                    var request = $http({
                                    method: "post",
                                    url:url,
                                    data: {
                        email: ""
                            },
                            headers: { 'Content-Type': 'application/x-www-form-urlencoded'
                            }
                        /*headers: { 'Content-Type': 'application/x-www-form-urlencoded' }
                        headers: { 'Content-Type': 'application/x-www-form-urlencoded' }*/
                        });

                        /* Check whether the HTTP Request is successful or not.*/ 
                        request.then(function (data) {
                            for(var i=0;i<data.data.length;i++)
                            {
                                var tempProduct=data.data[i].split("+");
                                var product;

                                if(tempProduct.length>0)
                                {
                                    product={'Name':tempProduct[0],Type:tempProduct[1],'Description':tempProduct[2],'Price':tempProduct[3],'ImagePath':tempProduct[5]};
                                    //console.log(product);
                                    if(product.Type=="Pizza")
                                    {
                                        console.log(product.ImagePath);
                                        obj={menuName:product.Name,menuPrice:product.Price,imagePath:product.ImagePath,tag:'Pizza'};
                                        obj.imagePath="http://stackpoint.tech"+obj.imagePath;
                                        //obj.imagePath="http://stackpoint.tech/resource/image/pizza1.jpg";
                                        console.log(obj.imagePath);
                                        $scope.Pizza.push(obj);
                                    }  
                                }
                                else
                                {
                                    product={'Name':'','Type':'','Description':'','Price':'','ImagePath':''};
                                }					
                                //console.log(tempProduct);
                                //$scope.productData.push(product);	
                            }
                            
                            console.log($scope.Pizza,length);
                            //console.log(data.data);
                        });
                    
        });