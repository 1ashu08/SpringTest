package com.auth.app.dao;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.auth.app.bean.User;
import com.auth.app.utility.MessageDigestUtility;

@Service
public class UserDao {
	
	@Autowired
	private UserRepository userRepo;

	public User saveUser(User user)
	{
		return userRepo.save(user);
	}
	
	public User createNewUser(User user)
	{
		user.setPassword(MessageDigestUtility.getMd5(user.getPassword()));
		return userRepo.save(user);
	}
	
	public List<User> findAll()
	{
		return userRepo.findAll();
	}
	
	public Optional<User> findUser(Integer id)
	{
		return userRepo.findById(id);
	}
	public User findByUserName(String userName)
	{
		return userRepo.findByUserName(userName);
	}
	
	public void deleteUser(User user)
	{
		userRepo.delete(user);
	}
	public void deleteAll()
	{
		userRepo.deleteAll();
	}
	public List<String> fetchAllUserName()
	{
		List<User> list=findAll();
		List<String> userName=new ArrayList<String>();
		
		for(User usr:list)
		{
			if(!userName.contains(usr.getUserName()))
				userName.add(usr.getUserName());
		}
		
		return userName;
	}
	public boolean validateUserName(String userName)
	{
		List<String> list=fetchAllUserName();
		if(list.contains(userName))
			return true;
		return false;
	}
	public boolean validateUserPassword(String userName,String password)
	{
		User user=findByUserName(userName);
		if(user==null)
			return false;
		String md5=MessageDigestUtility.getMd5(password);
		if(md5.equalsIgnoreCase(user.getPassword()))
			return true;
		
		return false;
	}
}
