package com.auth.app.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.auth.app.bean.User;

public interface UserRepository extends JpaRepository<User,Integer> {

	public User findByUserName(String userName);
}
