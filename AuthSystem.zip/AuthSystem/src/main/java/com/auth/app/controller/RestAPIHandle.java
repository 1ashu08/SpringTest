package com.auth.app.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.auth.app.bean.User;
import com.auth.app.dao.UserDao;

@RestController
public class RestAPIHandle {

	@Autowired
	UserDao userDao;
	
	@PostMapping(value="/saveEmployee")
	public void saveUser(@RequestBody User user )
	{
		userDao.saveUser(user);
	}

	@GetMapping(value="list")
	public List<User> listAll()
	{
		return userDao.findAll();
	}
	
	@GetMapping("/deleteAll")
	public String deleteAll()
	{
		userDao.deleteAll();
		return "Delete Complete";
	}
	
}
