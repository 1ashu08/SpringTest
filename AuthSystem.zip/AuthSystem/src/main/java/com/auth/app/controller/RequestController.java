package com.auth.app.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.auth.app.bean.User;
import com.auth.app.dao.UserDao;

@Controller
public class RequestController {

	@Autowired
	UserDao userDao;	
	
	@GetMapping("/crateUserForm")
	public String createUserForm(Model model)
	{
		model.addAttribute("user", new User());
		return "UserRegistration";
	}
	
	@GetMapping("/loginForm")
	public String loginUserForm(Model model)
	{
		model.addAttribute("user", new User());
		return "Login";
	}
	@PostMapping("/loginUser")
	public String loginUser(@ModelAttribute User user)
	{
		//model.addAttribute("user",new User());
		System.out.println("User is"+user.getUserName());
		
		boolean ch=userDao.validateUserPassword(user.getUserName(),user.getPassword());
		if(ch)
		{
			User usr=userDao.findByUserName(user.getUserName());
			user.setName(usr.getName());
			
			return "Welcome";
		}
		else
			return "Error";
		//return "Welcome";
	}
	
	
	
	@PostMapping("/createUser")
	public String createUser(@ModelAttribute User user)
	{
		//model.addAttribute("user",new User());
		System.out.println(user.getName());
		User ch=userDao.createNewUser(user);
		if(ch!=null)
			return "Welcome";
		else
			return "Error";
		//return "Welcome";
	}
}


